@include('theme.awasam.layout.header')
@yield('main')
@include('theme.awasam.layout.footer')
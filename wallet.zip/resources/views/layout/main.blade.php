@include('layout.header')
@yield('main')
@include('layout.footer')
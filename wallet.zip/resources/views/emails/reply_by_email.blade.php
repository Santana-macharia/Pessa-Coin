Name : {{ $data['name'] }} <br />
Email : {{ $data['email'] }} <br />
Phone Number : {{ $data['phone_number'] }} <br />
Message : {!!  $data['message'] !!}<br />